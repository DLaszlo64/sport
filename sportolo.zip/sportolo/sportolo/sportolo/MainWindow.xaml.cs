﻿using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace sportolo
{

    public partial class MainWindow : Window
    {
        private List<Sportolo> versenyzok = new List<Sportolo>();
        private string fajlnev = "versenyzok.txt";
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            MintaAdatGeneralas();
            AdatBeolvasas();
            StatisztikakKiszamitasa();
        }


        private void MintaAdatGeneralas()
        {
            if (!File.Exists(fajlnev))
            {
                string[] mintaSorok = {
                    "Hosszú Katinka;95;Magyarország",
                    "Michael Phelps;98;USA",
                    "Cseh László;92;Magyarország",
                    "Adam Peaty;88;Egyesült Királyság",
                    "Milák Kristóf;96;Magyarország"
                };
                File.WriteAllLines(fajlnev, mintaSorok, Encoding.UTF8);
            }
        }


        private void AdatBeolvasas()
        {
            versenyzok.Clear();
            string[] sorok = File.ReadAllLines(fajlnev, Encoding.UTF8);

            foreach (string sor in sorok)
            {
                if (sor != "")
                {
                    versenyzok.Add(new Sportolo(sor));
                }
            }
        }

        private void StatisztikakKiszamitasa()
        {
            if (versenyzok.Count == 0) return;

       
            double atlag = versenyzok.Average(v => v.Pontszam);
            lblAtlag.Text = atlag.ToString("0.00") + " pont";

            int magyarokSzama = versenyzok.Count(v => v.Orszag == "Magyarország");
            lblMagyarok.Text = magyarokSzama + " fő";

            var gyoztes = versenyzok.OrderByDescending(v => v.Pontszam).First();
            lblGyoztes.Text = gyoztes.Nev + " (" + gyoztes.Pontszam + " pont)";

    
            bool vanAlacsony = versenyzok.Any(v => v.Pontszam < 90);
            if (vanAlacsony == true)
            {
                lblVanAlacsony.Text = "Igen, van 90 pont alatti.";
            }
            else
            {
                lblVanAlacsony.Text = "Nincs 90 pont alatti.";
            }

            string keresettNev = "Cseh László";
            var talalat = versenyzok.FirstOrDefault(v => v.Nev == keresettNev);
            if (talalat != null)
            {
                lblCsehLaszlo.Text = talalat.Pontszam + " pont";
            }
            else
            {
                lblCsehLaszlo.Text = "Nem található a listában.";
            }
        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {

            string beirtNev = txtUjNev.Text;

            if (beirtNev == "")
            {
                MessageBox.Show("Kérlek, írj be egy nevet a mezőbe!", "Figyelmeztetés");
                return;
            }

       
            string ujSor = beirtNev + ";100;Magyarország";

            File.AppendAllText(fajlnev, ujSor + Environment.NewLine, Encoding.UTF8);

            AdatBeolvasas();
            StatisztikakKiszamitasa();

      
            txtUjNev.Clear();

   
            MessageBox.Show(beirtNev + " sikeresen hozzáadva és elmentve!", "Sikeres mentés");
        }
    }
}